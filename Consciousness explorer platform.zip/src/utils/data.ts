// Mock data for the application
export interface Transcript {
  id: string;
  title: string;
  category: string;
  excerpt: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'other';
  timestamp: string;
}

export const TRANSCRIPTS: Transcript[] = [
  { id: '1', title: "The Council of Elders", category: "Between Lives", excerpt: "The soul stood before a panel of beings reviewing past life choices..." },
  { id: '2', title: "Tunnel of Light Experience", category: "NDE", excerpt: "I moved rapidly through a dark void towards a brilliant, warm light..." },
  { id: '3', title: "Pre-Birth Memory", category: "Hypnotherapy", excerpt: "I chose the body and the life challenges before I was born..." },
  { id: '4', title: "Talking to Bill Paxton", category: "Mediumship", excerpt: "Communication with the actor revealed his perspective on crossing over..." },
  { id: '5', title: "The Architecture of the Afterlife", category: "Research", excerpt: "Mapping the geography of the spirit world using consistent reports..." },
  { id: '6', title: "Observer Effect in Daily Life", category: "Quantum", excerpt: "How our focus shapes the reality we experience moment to moment..." },
  { id: '7', title: "Viking Incarnation", category: "Past Life", excerpt: "A vivid recollection of a raid on the northern coast..." },
  { id: '8', title: "The Flipside", category: "Research", excerpt: "Exploring the concept of the afterlife as a staging area..." }
];

export const BOT_RESPONSES = [
  "Consciousness is fundamental to the universe, not an emergent property.",
  "The brain acts as a reducing valve, limiting universal awareness.",
  "Time is a construct of the physical plane. In the afterlife, it is non-linear.",
  "Have you read the transcript from the hypnotherapy session regarding pre-birth planning?",
  "We are all receivers tuned to different frequencies.",
  "The observer effect suggests we create reality by observing it."
];