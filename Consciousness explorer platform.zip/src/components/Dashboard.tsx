import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Play, Send } from 'lucide-react';
import { BOT_RESPONSES } from '../utils/data';

export function Dashboard() {
  const [messages, setMessages] = useState<Array<{ id: number; text: string; sender: 'user' | 'other'; time: string }>>([
    { id: 1, text: "Welcome to the Receiver Network. The brain is a receiver, not a generator.", sender: 'other', time: '10:00 AM' }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;
    const newMsg = {
      id: Date.now(),
      text: input,
      sender: 'user' as const,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, newMsg]);
    setInput('');

    setTimeout(() => {
      const randomResponse = BOT_RESPONSES[Math.floor(Math.random() * BOT_RESPONSES.length)];
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: randomResponse,
        sender: 'other',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900/60 backdrop-blur-xl border-white/10 text-white">
        <CardHeader>
          <CardTitle className="text-cyan-400">Consciousness Stream</CardTitle>
          <CardDescription className="text-slate-400">Real-time discussion on the non-local nature of awareness.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-96 overflow-y-auto mb-4 p-4 bg-black/20 rounded-lg border border-white/5 space-y-3">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`p-3 rounded-lg max-w-[80%] ${msg.sender === 'user' ? 'ml-auto bg-indigo-600/20 border border-indigo-500/30' : 'mr-auto bg-white/5 border border-white/10'}`}
              >
                <div className="text-xs text-cyan-400 mb-1">{msg.sender === 'user' ? 'You' : 'Observer_' + Math.floor(Math.random() * 100)} • {msg.time}</div>
                <div className="text-sm">{msg.text}</div>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Share your observation..."
              className="bg-black/30 border-white/10 text-white focus:border-cyan-400"
            />
            <Button onClick={handleSend} className="bg-indigo-600 hover:bg-indigo-700">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="bg-slate-900/60 backdrop-blur-xl border-white/10 text-white">
          <CardHeader>
            <CardTitle className="text-amber-400 text-lg">Talking to Bill Paxton</CardTitle>
            <CardDescription className="text-slate-400 text-sm">Richard Martini explores communication with the deceased.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/5">
              <Play className="w-4 h-4 mr-2" /> Play Preview
            </Button>
          </CardContent>
        </Card>
        <Card className="bg-slate-900/60 backdrop-blur-xl border-white/10 text-white">
          <CardHeader>
            <CardTitle className="text-amber-400 text-lg">After with Bruce Greyson</CardTitle>
            <CardDescription className="text-slate-400 text-sm">Decades of NDE research into the nature of mind.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/5">
              <Play className="w-4 h-4 mr-2" /> Play Preview
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}