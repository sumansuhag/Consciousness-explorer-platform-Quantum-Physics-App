import { useState } from 'react';
import { Input } from '../components/ui/input';
import { Card, CardContent } from '../components/ui/card';
import { TRANSCRIPTS } from '../utils/data';

export function Archive() {
  const [filter, setFilter] = useState('');

  const filtered = TRANSCRIPTS.filter(t =>
    t.title.toLowerCase().includes(filter.toLowerCase()) ||
    t.category.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="bg-slate-900/60 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
        <h2 className="text-2xl font-bold text-white mb-4 border-l-4 border-cyan-400 pl-4">Transcript Archive</h2>
        <Input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Search NDEs, OBEs, Hypnotherapy..."
          className="bg-black/30 border-white/10 text-white focus:border-cyan-400"
        />
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((t) => (
          <Card
            key={t.id}
            className="bg-white/5 backdrop-blur-xl border-white/10 text-white cursor-pointer hover:border-cyan-400 transition-all hover:-translate-y-1"
          >
            <CardContent className="p-6">
              <span className="inline-block px-2 py-1 rounded text-xs bg-cyan-900/30 text-cyan-400 mb-3">
                {t.category}
              </span>
              <h3 className="text-lg font-semibold mb-2">{t.title}</h3>
              <p className="text-sm text-slate-400">{t.excerpt}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}