import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';

interface Particle {
  id: number;
  x: number;
  y: number;
}

export function QuantumLab() {
  const [particles, setParticles] = useState<Particle[]>([]);
  const [collapsed, setCollapsed] = useState(false);

  const handleStageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setParticles(prev => [...prev, { id: Date.now(), x, y }]);
    setCollapsed(true);
  };

  const reset = () => {
    setParticles([]);
    setCollapsed(false);
  };

  return (
    <Card className="bg-slate-900/60 backdrop-blur-xl border-white/10 text-white">
      <CardHeader>
        <CardTitle className="text-2xl border-l-4 border-cyan-400 pl-4">Quantum Observer Lab</CardTitle>
        <CardDescription className="text-slate-400 pl-5">
          Click anywhere in the void to collapse the probability wave.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div
          onClick={handleStageClick}
          className="h-96 bg-black rounded-xl border border-white/10 relative overflow-hidden cursor-crosshair"
        >
          <div className="absolute top-4 left-4 bg-black/70 px-3 py-1 rounded text-xs font-mono text-amber-400 border border-amber-400/30">
            State: {collapsed ? 'Collapsed' : 'Superposition'}
          </div>
          {particles.map((p) => (
            <div
              key={p.id}
              className="absolute w-3 h-3 bg-amber-400 rounded-full -translate-x-1/2 -translate-y-1/2 shadow-[0_0_10px_#F59E0B]"
              style={{ left: p.x, top: p.y }}
            />
          ))}
        </div>
        <div className="flex items-center gap-4">
          <Button onClick={reset} className="bg-indigo-600 hover:bg-indigo-700">
            Reset Experiment
          </Button>
          <span className="text-sm text-slate-500">
            Based on the Copenhagen interpretation & observer-participation models.
          </span>
        </div>
      </CardContent>
    </Card>
  );
}