import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Slider } from '../components/ui/slider'; // Assuming Slider is available or using standard input range styled

export function Simulator() {
  const [bandwidth, setBandwidth] = useState([50]);
  const [frequency, setFrequency] = useState([20]);

  const blurAmount = 10 - (bandwidth[0] / 10);
  const scale = 0.5 + (bandwidth[0] / 100);
  const opacity = 0.3 + (bandwidth[0] / 140);
  const hue = 200 + (frequency[0] * 1.5);

  let statusText = "Status: Normal Waking Consciousness";
  let boxShadow = "0 0 30px rgba(79, 70, 229, 0.4)";

  if (bandwidth[0] < 30) {
    statusText = "Status: Deep Physical Filter (Limited Awareness)";
    boxShadow = "none";
  } else if (bandwidth[0] < 70) {
    statusText = "Status: Expanded Awareness (Meditative State)";
    boxShadow = `0 0 30px hsla(${hue}, 70%, 50%, 0.5)`;
  } else {
    statusText = "Status: Non-Local Connection (Receiver Mode)";
    boxShadow = `0 0 60px hsla(${hue}, 70%, 50%, 0.8)`;
  }

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900/60 backdrop-blur-xl border-white/10 text-white">
        <CardHeader>
          <CardTitle className="text-2xl border-l-4 border-cyan-400 pl-4">Receiver Filter Simulation</CardTitle>
          <CardDescription className="text-slate-400 pl-5">
            Adjust the "bandwidth" of the brain's filter to see how consciousness is perceived.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <label className="block mb-4 text-cyan-400 font-medium">Brain Bandwidth (Filter)</label>
              <Slider
                value={bandwidth}
                onValueChange={setBandwidth}
                max={100}
                step={1}
                className="w-full"
              />
              <p className="text-xs text-slate-500 mt-2">Low bandwidth = Physical reality only. High = Expanded awareness.</p>
            </div>
            <div>
              <label className="block mb-4 text-amber-400 font-medium">Signal Frequency</label>
              <Slider
                value={frequency}
                onValueChange={setFrequency}
                max={100}
                step={1}
                className="w-full"
              />
              <p className="text-xs text-slate-500 mt-2">Tune into different "planes" or incarnational memories.</p>
            </div>
          </div>

          <div
            className="h-80 rounded-xl border border-white/10 flex items-center justify-center relative overflow-hidden transition-all duration-500"
            style={{
              background: 'radial-gradient(circle at center, #1e293b 0%, #020617 100%)',
              filter: `blur(${blurAmount}px)`
            }}
          >
            <div
              className="w-32 h-32 rounded-full transition-all duration-500"
              style={{
                background: `linear-gradient(135deg, hsl(${hue}, 70%, 50%), #4F46E5)`,
                transform: `scale(${scale})`,
                opacity: opacity,
                boxShadow: boxShadow
              }}
            />
            <div className="absolute bottom-4 text-slate-400 text-sm font-mono">
              {statusText}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}