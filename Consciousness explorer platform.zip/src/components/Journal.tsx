import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Textarea } from '../components/ui/textarea';
import { Trash2 } from 'lucide-react';

interface Entry {
  id: number;
  date: string;
  text: string;
}

export function Journal() {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [text, setText] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem('receiver_journal');
    if (saved) {
      setEntries(JSON.parse(saved));
    }
  }, []);

  const saveEntry = () => {
    if (!text.trim()) return;
    const newEntry: Entry = {
      id: Date.now(),
      date: new Date().toLocaleString(),
      text
    };
    const updated = [newEntry, ...entries];
    setEntries(updated);
    localStorage.setItem('receiver_journal', JSON.stringify(updated));
    setText('');
  };

  const deleteEntry = (id: number) => {
    const updated = entries.filter(e => e.id !== id);
    setEntries(updated);
    localStorage.setItem('receiver_journal', JSON.stringify(updated));
  };

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900/60 backdrop-blur-xl border-white/10 text-white">
        <CardHeader>
          <CardTitle className="text-2xl border-l-4 border-cyan-400 pl-4">Reflection Journal</CardTitle>
          <CardDescription className="text-slate-400 pl-5">
            Encrypted locally. Your thoughts remain yours.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Record your observations from the meditation or simulation..."
            className="bg-black/30 border-white/10 text-white focus:border-cyan-400 min-h-[150px]"
          />
          <Button onClick={saveEntry} className="bg-indigo-600 hover:bg-indigo-700">
            Save Entry
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-slate-900/60 backdrop-blur-xl border-white/10 text-white">
        <CardHeader>
          <CardTitle className="text-xl">Past Entries</CardTitle>
        </CardHeader>
        <CardContent>
          {entries.length === 0 ? (
            <p className="text-slate-500 text-sm">No entries yet.</p>
          ) : (
            <div className="space-y-4">
              {entries.map((e) => (
                <div key={e.id} className="p-4 border-b border-white/10 flex justify-between items-start group">
                  <div>
                    <p className="text-white text-sm mb-1 line-clamp-2">{e.text}</p>
                    <p className="text-xs text-slate-500">{e.date}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteEntry(e.id)}
                    className="text-red-400 hover:text-red-300 hover:bg-red-900/20 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}