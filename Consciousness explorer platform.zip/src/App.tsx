import { useState } from 'react';
import { Button } from './components/ui/button';
import { CosmicBackground } from './components/CosmicBackground';
import { Dashboard } from './components/Dashboard';
import { Archive } from './components/Archive';
import { Simulator } from './components/Simulator';
import { QuantumLab } from './components/QuantumLab';
import { Journal } from './components/Journal';
import { Activity, BookOpen, Sliders, Atom, NotebookPen } from 'lucide-react';

type Tab = 'dashboard' | 'archive' | 'simulator' | 'quantum' | 'journal';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');

  const tabs = [
    { id: 'dashboard' as Tab, label: 'Dashboard', icon: Activity },
    { id: 'archive' as Tab, label: 'Transcripts', icon: BookOpen },
    { id: 'simulator' as Tab, label: 'Filter Sim', icon: Sliders },
    { id: 'quantum' as Tab, label: 'Quantum Lab', icon: Atom },
    { id: 'journal' as Tab, label: 'Journal', icon: NotebookPen },
  ];

  return (
    <div className="min-h-screen bg-[#0B1026] text-slate-100 font-sans selection:bg-cyan-500/30">
      <CosmicBackground />
      
      <div className="relative z-10 flex flex-col h-screen">
        {/* Header */}
        <header className="flex justify-between items-center px-6 py-4 bg-[#0B1026]/80 backdrop-blur-md border-b border-white/10">
          <div className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-indigo-600 bg-clip-text text-transparent tracking-tight">
            RECEIVER
          </div>
          <div className="flex items-center gap-3 text-sm text-slate-400">
            <span>Observer: Online</span>
            <div className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_10px_#06B6D4] animate-pulse" />
          </div>
        </header>

        {/* Navigation */}
        <nav className="flex justify-center py-4 px-4 gap-2 flex-wrap">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <Button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                variant={activeTab === tab.id ? 'default' : 'ghost'}
                className={`
                  rounded-full px-5 transition-all duration-300
                  ${activeTab === tab.id 
                    ? 'bg-indigo-600 text-white shadow-[0_0_15px_rgba(79,70,229,0.5)] border border-indigo-500' 
                    : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'}
                `}
              >
                <Icon className="w-4 h-4 mr-2" />
                {tab.label}
              </Button>
            );
          })}
        </nav>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-6xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
            {activeTab === 'dashboard' && <Dashboard />}
            {activeTab === 'archive' && <Archive />}
            {activeTab === 'simulator' && <Simulator />}
            {activeTab === 'quantum' && <QuantumLab />}
            {activeTab === 'journal' && <Journal />}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;